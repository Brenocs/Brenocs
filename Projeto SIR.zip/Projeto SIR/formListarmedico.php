
 <?php require_once("Medico.php") ?>
 <?php require_once("conecta.php") ?>
 <?php require_once("banco-medico.php") ?>
<h1> <center>Listar Médicos</center> </h1>
<?php	  
  listaMedico($conexao);
?>