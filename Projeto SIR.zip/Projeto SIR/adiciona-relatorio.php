
       <?php require_once("conecta.php") ?>
	   <?php require_once("Relatorio.php") ?>
       <?php require_once("banco-relatorio.php") ?>
       <?php
	   
//Crie um objeto chamado  $funcionario  
		$relatorio= new relatorio;
			
//Aqui o objeto $funcionario deverá receber os atributos 
		$relatorio->cpf=$_POST["cpf"];
        $relatorio->nome=$_POST["nome"];
		$relatorio->prontuario=$_POST["prontuario"];	
			
			
//Aqui deverá ter o método insereFuncionario --
        if (insererelatorio($conexao, $relatorio)){  ?>
			 <center>
			    
			   <table >
			   <tr>
			      <th>Cadastrado com sucesso!</th>
			   </tr>

			    <tr>
			       <td>CPF:     <?php echo  $relatorio->cpf; ?></td>
				</tr>
				<tr>
			       <td>Nome:<?php echo  $relatorio->nome;?></td>
				</tr>
				<tr>
			       <td>Prontuário: <?php echo    $relatorio->prontuario;?></td>
				</tr>
				</table>
		<?php
	
		      }else{
		?>
			  <p>Não foi adicionado!</p>
			
		<?php echo mysqli_error($conexao);
		
			  }
//--------------------------------------------------------------
?>
		 <h3>
			<a href="formListar.php">Listar</a><br>
        	<a href="localizar.php" >Localizar</a> 
			
		 </h3>
		</center>
     