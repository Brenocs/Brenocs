<?php 
		 class Paciente {
		 	public $id;
			public $cpf;
			public $nome;
			public $rg;
			public $email;
			public $nascimento;
			public $logradouro;
			public $numero;
			public $bairro;
			public $cidade;
			public $estado;
			public $sexo;
			public $doencas;
			public $dtexame;
			public $horario;
			public $lexame;
			public $texame;
			public $obs;
	}

?>