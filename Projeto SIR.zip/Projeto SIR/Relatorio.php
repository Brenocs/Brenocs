<?php 
		 class Relatorio {
		 	public $id;
			public $cpf;
			public $nome;
			public $prontuario;

	}

?>