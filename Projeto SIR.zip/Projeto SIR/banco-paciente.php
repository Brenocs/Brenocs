 <?php require_once("paciente.php") ?>
    <?php

// -------MÉTODO PARA INSERIR------------------------------
	  function inserePaciente($conexao,$paciente){ 

		$sql="insert into cadastro(cpf,nome,rg,email,nascimento,logradouro,numero,bairro,cidade,estado,sexo,doencas,dtexame,horario,lexame,texame,obs) values 
			('$paciente->cpf',
			 '$paciente->nome',
			 '$paciente->rg',
			 '$paciente->email',
			 '$paciente->nascimento',
			 '$paciente->logradouro',
			 '$paciente->numero',
			 '$paciente->bairro',
			 '$paciente->cidade',
			 '$paciente->estado',
			 '$paciente->sexo',
			 '$paciente->doencas',
			 '$paciente->dtexame',
			 '$paciente->horario',
			 '$paciente->lexame',
			 '$paciente->texame',
			 '$paciente->obs'
			)";
			$resultado =mysqli_query($conexao, $sql);
         return $resultado ;
	    }
		
// --------MÉTODO PARA DELETAR(alterar)--------------------------------------------------------------------

	
		function removePaciente($conexao,$id) {
				$sql ="delete from cadastro where id = '$id';";
				$resultado =mysqli_query ($conexao,$sql);   
	    return $resultado; 
		}
	
		 

//---------MÉTODO PARA LISTAR------------------------------------------------------------------------------
	
		 function listaPaciente($conexao){
			  
				$sql="select  * from cadastro";
				$resultado= mysqli_query($conexao,$sql );
				 
		 while($array=mysqli_fetch_assoc($resultado)) { ?>
					
			  <center>
					 <form action=alterarFormpaciente.php  method=GET>
	                  <table >
							  <tr>
								  
								   <td><input type=hidden value= <?php echo $array['id'];?> name=id> </td> 
							  </tr>
							  <tr>
								   <td>CPF </td>
								   <td> <input type=text value= <?php echo $array['cpf'];?> name=cpf> </td>
							  </tr>
							  <tr>
								   <td>Nome</td>
								   <td> <input type=text value= <?php echo $array['nome'];?>  name=nome> </td>
							  </tr>
							   <tr>
								   <td>RG</td>
								   <td> <input type=text value= <?php echo $array['rg'];?>  name=rg> </td>
							  </tr>
							   <tr>
								   <td>Email</td>
								   <td> <input type=text value= <?php echo $array['email'];?>  name=email> </td>
							  </tr>
							  <tr>
								   <td>Nascimento</td>
								   <td> <input type=date value= <?php echo $array['nascimento'];?>  name=nascimento> </td>
							  </tr>
							  <tr>
								   <td>Logradouro</td>
								   <td> <input type=text value= <?php echo $array['logradouro'];?>  name=logradouro> </td>
							  </tr>
							  <tr>
								   <td>Número</td>
								   <td> <input type=text value= <?php echo $array['numero'];?>  name=numero> </td>
							  </tr>
							  <tr>
								   <td>Bairro</td>
								   <td> <input type=text value= <?php echo $array['bairro'];?>  name=bairro> </td>
							  </tr>
							  <tr>
								   <td>Cidade</td>
								   <td> <input type=text value= <?php echo $array['cidade'];?>  name=cidade> </td>
							  </tr>
							  <tr>
								   <td>Estado</td>
								   <td> <input type=text value= <?php echo $array['estado'];?>  name=estado> </td>
							  </tr>
							  <tr>
								   <td>Sexo</td>
								   <td> <input type=text value= <?php echo $array['sexo'];?>  name=sexo> </td>
							  </tr>
							  <tr>
								   <td>Doenças Prescritas</td>
								   <td> <input type=text value= <?php echo $array['doencas'];?>  name=doencas> </td>
							  </tr>
							  <tr>
								   <td>Data do Exame</td>
								   <td> <input type=text value= <?php echo $array['dtexame'];?>  name=dtexame> </td>
							  </tr>
							  <tr>
								   <td>Horário do Exame</td>
								   <td> <input type=text value= <?php echo $array['horario'];?>  name=horario> </td>
							  </tr>
							  <tr>
								   <td>Local do Exame</td>
								   <td> <input type=text value= <?php echo $array['lexame'];?>  name=lexame> </td>
							  </tr>
							  <tr>
								   <td>Tipo do Exame</td>
								   <td> <input type=text value= <?php echo $array['texame'];?>  name=texame> </td>
							  </tr>
							  <tr>
								   <td>Obs</td>
								   <td> <input type=text value= <?php echo $array['obs'];?>  name=obs> </td>
							  </tr>
							  <tr> 
								  <td colspan =2><center><input type=submit value=Alterar></center> </td>
							  </tr>
					  	</form>
<!-----------FORMULÁRIO ---------------------------------------  -->
						 <form action="remove-paciente.php" method="post">
								
								<table >	
									 <tr>
										 <td><input type=hidden value= <?php echo $array['id'];?> name=id>
										 <td>  <button> Remover  </button></td>
									 </tr>
								</table >
							 
						      </form> 
<!-------------------------------------------------  -->
                 	 </table >
              </center>
	 <?php }   
 }  
 
 //-----FUNÇÃO PARA ALTERAR(alterar) --------------------------------------------------
 
 function alterar($conexao,$id,$cpf,$nome,$rg,$email,$nascimento,$logradouro,$numero,$bairro,$cidade,$estado,$sexo,$doencas,$dtexame,$horario,$lexame,$texame,$obs){
	   
       	$sql = "UPDATE cadastro SET         cpf='$cpf'
       	                                    nome='$nome', 
											rg= '$rg',
											email = '$email',
											nascimento = '$nascimento',
											logradouro = '$logradouro',
											numero = '$numero',
											bairro = '$bairro',
											cidade = '$cidade',
											estado = '$estado',
											sexo = '$sexo',
											doencas = '$doencas',
											dtexame = '$dtexame',
											horario = '$horario',
											lexame = '$lexame',
											texame = '$texame',
											obs = '$obs'		 WHERE id = $id";
		
		$resultado= mysqli_query($conexao,$sql);
	     
     return $resultado;
  }
  //-----------------------------------------------------------------------
 