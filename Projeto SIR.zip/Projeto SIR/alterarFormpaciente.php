 <?php require_once("Paciente.php") ?>
 <?php require_once("conecta.php") ?>
 <?php require_once("banco-paciente.php") ?>
 
 <?php
               $id=  $_GET["id"];
               $cpf= $_GET["cpf"];
			   $nome=$_GET["nome"];
			   $cpf= $_GET["email"];
	           $nascimento=$_GET["nascimento"];
			   $logradouro=$_GET["logradouro"];
			   $numero=$_GET["numero"];
			   $bairro=$_GET["bairro"];
			   $cidade=$_GET["cidade"];
			   $estado=$_GET["estado"];
			   $sexo=$_GET["sexo"];
			   $doencas=$_GET["doencas"];
			   $dtexame=$_GET["dtexame"];
			   $horario=$_GET["horario"];
			   $lexame=$_GET["lexame"];
			   $texame=$_GET["texame"];
			   $obs=$_GET["obs"];

			   
 alterar($conexao,$id,$cpf,$nome,$email,$nascimento,$logradouro,$numero,$bairro,$cidade,$estado,$sexo,$doencas,$dtexame,$horario,$lexame,$texame,$obs);
    header("Location:formListarpaciente.php?removido=true");
 
  ?>
  
  