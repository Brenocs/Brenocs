<?php 
		 class Familia {
			public $id;
			public $nome;
			public $email;
			public $senha;
			public $cpf;

	}

?>