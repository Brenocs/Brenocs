
 <?php require_once("Paciente.php") ?>
 <?php require_once("conecta.php") ?>
 <?php require_once("banco-paciente.php") ?>
<h1> <center>Listar Pacientes</center> </h1>
<?php	  
  listaPaciente($conexao);
?>