<?php require_once("conecta.php") ?>
  <?php require_once("banco-familia.php") ?>

<?php 

 $id = $_POST['id'];
 removeFamilia($conexao,$id);
 
 header("Location:formListarfamilia.php?removido=true");
 

?>