<?php 
		 class Medico {
			public $id;
			public $nome;
			public $email;
			public $senha;
			public $cpf;
			public $area;

	}

?>