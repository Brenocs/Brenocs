
       <?php require_once("conecta.php") ?>
	   <?php require_once("Familia.php") ?>
       <?php require_once("banco-familia.php") ?>
       <?php
	   
//Crie um objeto chamado  $funcionario  
		$familia= new familia;
			
//Aqui o objeto $funcionario deverá receber os atributos 
        $familia->nome=$_POST["nome"];
		$familia->email=$_POST["email"];
		$familia->senha=$_POST["senha"];
		$familia->cpf=$_POST["cpf"];	
			
			
//Aqui deverá ter o método insereFuncionario --
        if (inserefamilia($conexao, $familia)){  ?>
			 <center>
			    
			   <table >
			   <tr>
			      <th>Cadastrado com sucesso!</th>
			   </tr>

			    <tr>
			       <td>Nome:     <?php echo  $familia->nome; ?></td>
				</tr>
				<tr>
			       <td>Email:<?php echo  $familia->email;?></td>
				</tr>
				<tr>
			       <td>Senha: <?php echo    $familia->senha;?></td>
				</tr>
				<tr>
			       <td>CPF: <?php echo    $familia->cpf;?></td>
				</tr>
				</table>
		<?php
	
		      }else{
		?>
			  <p>Não foi adicionado!</p>
			
		<?php echo mysqli_error($conexao);
		
			  }
//--------------------------------------------------------------
?>
		 <h3>
			<a href="formListar.php">Listar</a><br>
        	<a href="localizar.php" >Localizar</a> 
			
		 </h3>
		</center>
                
    