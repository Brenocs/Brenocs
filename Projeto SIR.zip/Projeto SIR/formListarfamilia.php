
 <?php require_once("Familia.php") ?>
 <?php require_once("conecta.php") ?>
 <?php require_once("banco-familia.php") ?>
<h1> <center>Listar Familia</center> </h1>
<?php	  
  listaFamilia($conexao);
?>