<?php require_once("Relatorio.php") ?>
    <?php

// -------MÉTODO PARA INSERIR------------------------------
	  function insereRelatorio($conexao,$relatorio){ 

		$sql="insert into relatorio(cpf,nome,prontuario) values 
			('$relatorio->cpf',
			 '$relatorio->nome',
			 '$relatorio->prontuario',
			)";
			$resultado =mysqli_query($conexao, $sql);
         return $resultado ;
	    }
		
// --------MÉTODO PARA DELETAR(alterar)--------------------------------------------------------------------

	
		function removeRelatorio($conexao,$id) {
				$sql ="delete from relatorio where id = '$id';";
				$resultado =mysqli_query ($conexao,$sql);   
	    return $resultado; 
		}
	
		 

//---------MÉTODO PARA LISTAR------------------------------------------------------------------------------
	
		 function listaMedico($conexao){
			  
				$sql="select  * from relatorio";
				$resultado= mysqli_query($conexao,$sql );
				 
		 while($array=mysqli_fetch_assoc($resultado)) { ?>
					
			  <center>
					 <form action=alterarFormrelatorio.php  method=GET>
	                  <table >
							  <tr>
								  
								   <td><input type=hidden value= <?php echo $array['id'];?> name=id> </td> 
							  </tr>
							  <tr>
								   <td>CPF</td>
								   <td> <input type=text value= <?php echo $array['cpf'];?>  name=cpf> </td>
							  </tr>
							   <tr>
								   <td>Nome</td>
								   <td> <input type=text value= <?php echo $array['nome'];?>  name=nome> </td>
							  </tr>
							  <tr>
								   <td>Prontuário</td>
								   <td> <input type=text value= <?php echo $array['prontuario'];?>  name=prontuario> </td>
							  </tr>
							  <tr> 
								  <td colspan =2><center><input type=submit value=Alterar></center> </td>
							  </tr>
					  	</form>
<!-----------FORMULÁRIO ---------------------------------------  -->
						 <form action="remove-relatorio.php" method="post">
								
								<table >	
									 <tr>
										 <td><input type=hidden value= <?php echo $array['id'];?> name=id>
										 <td>  <button> Remover  </button></td>
									 </tr>
								</table >
							 
						      </form> 
<!-------------------------------------------------  -->
                 	 </table >
              </center>
	 <?php }   
 }  
 
 //-----FUNÇÃO PARA ALTERAR(alterar) --------------------------------------------------
 
 function alterar($conexao,$id,$cpf,$nome,$prontuario){
	   
       	$sql = "UPDATE relatorio SET        cpf='$cpf',
       	                                    nome = '$nome', 
											prontuario= '$prontuario'  WHERE id = $id";
		
		$resultado= mysqli_query($conexao,$sql);
	     
     return $resultado;
  }
  //-----------------------------------------------------------------------
 