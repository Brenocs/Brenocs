<?php require_once ("conecta.php")?>
<?php require_once ("banco-medico.php")?>
<?php require_once ("Medico.php")?>

<?php
	$medico = new medico();
	$medico->nome=$_POST["nome"];
	$medico->email=$_POST["email"];
	$medico->senha=$_POST["senha"];
	$medico->cpf=$_POST["cpf"];
	$medico->area=$_POST["area"];
	

if (inseremedico($conexao, $medico)){  ?>
			 <center>
			    
			   <table >
			   <tr><br>
			      <th>Cadastrado com sucesso!</th>
			   </tr>
			     <tr>
			       <td><br>Codigo:  <?php echo $medico->nome; ?></td>
				</tr>
			    <tr>
			       <td>Nome:   <?php echo $medico->nome; ?></td>
				</tr>
				<tr>
			       <td>Email: <?php  echo$medico->email; ?></td>
				</tr>
				<tr>
			      <td>Senha: <?php  echo$medico->senha; ?></td>
				</tr>
				<tr>
			       <td>CPF: <?php  echo$medico->cpf; ?></td>
				</tr>
				<tr>
			       <td>Área de Atuação : <?php  echo$medico->area; ?></td>
				</tr>


				</table>
		<?php
	
		      }else{
		?>
			  <h3>Paciente não adicionado!!</h3>
			
		<?php echo mysqli_error($conexao);
		
			  }
		
		?>
		<!--
<link rel="Stylesheet" href="css/bootstrap.css">
<br><br><br><br>
   <!-- <a href="formListar.php" button type="submit" class="btn btn-default btn-sm active" role="button">Listar</a></button></button><br><br>-->
 <!--<br/><a href="localizar.php">LOCALIZAR</a> <br><br>
 <a href="Apresentacao.php" button type="submit" class="btn btn-default btn-sm active" role="button">Voltar</a></button>-->

</center>