 <?php require_once("Relatorio.php") ?>
 <?php require_once("conecta.php") ?>
 <?php require_once("banco-relatorio.php") ?>
 
 <?php
               $id=  $_GET["id"];
               $cpf= $_GET["cpf"];
			   $nome=$_GET["nome"];
			   $prontuario= $_GET["prontuario"];

			   
 alterar($conexao,$id,$cpf,$nome,$prontuario);
 
    header("Location:formListarrelatorio.php?removido=true");
 
  ?>
  