<?php require_once("conecta.php") ?>
  <?php require_once("banco-medico.php") ?>

<?php 

 $id = $_POST['id'];
 removeMedico($conexao,$id);
 
 header("Location:formListarmedico.php?removido=true");
 

?>