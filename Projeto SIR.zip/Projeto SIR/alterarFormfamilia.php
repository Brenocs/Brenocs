 <?php require_once("Familia.php") ?>
 <?php require_once("conecta.php") ?>
 <?php require_once("banco-familia.php") ?>
 
 <?php
               $id=  $_GET["id"];
			   $nome=$_GET["nome"];
			   $cpf= $_GET["email"];
	           $senha=$_GET["senha"];
	           $cpf= $_GET["cpf"];

			   
 alterar($conexao,$id,$nome,$email,$enha,$cpf);
    header("Location:formListarfamilia.php?removido=true");
 
  ?>