 <?php require_once("Medico.php") ?>
    <?php

// -------MÉTODO PARA INSERIR------------------------------
	  function insereMedico($conexao,$medico){ 

		$sql="insert into cadmed(nome,email,senha,cpf,area) values 
			('$medico->nome',
			 '$medico->email',
			 '$medico->senha',
			 '$medico->cpf',
			 '$medico->area'
			)";
			$resultado =mysqli_query($conexao, $sql);
         return $resultado ;
	    }
		
// --------MÉTODO PARA DELETAR(alterar)--------------------------------------------------------------------

	
		function removeMedico($conexao,$id) {
				$sql ="delete from cadmed where id = '$id';";
				$resultado =mysqli_query ($conexao,$sql);   
	    return $resultado; 
		}
	
		 

//---------MÉTODO PARA LISTAR------------------------------------------------------------------------------
	
		 function listaMedico($conexao){
			  
				$sql="select  * from cadmed";
				$resultado= mysqli_query($conexao,$sql );
				 
		 while($array=mysqli_fetch_assoc($resultado)) { ?>
					
			  <center>
					 <form action=alterarFormmedico.php  method=GET>
	                  <table >
							  <tr>
								  
								   <td><input type=hidden value= <?php echo $array['id'];?> name=id> </td> 
							  </tr>
							  <tr>
								   <td>Nome</td>
								   <td> <input type=text value= <?php echo $array['nome'];?>  name=nome> </td>
							  </tr>
							   <tr>
								   <td>Email</td>
								   <td> <input type=text value= <?php echo $array['email'];?>  name=email> </td>
							  </tr>
							  <tr>
								   <td>Senha</td>
								   <td> <input type=text value= <?php echo $array['senha'];?>  name=senha> </td>
							  </tr>
							  <tr>
								   <td>CPF</td>
								   <td> <input type=text value= <?php echo $array['cpf'];?>  name=cpf> </td>
							  </tr>
							  <tr>
								   <td>Área de Atuação</td>
								   <td> <input type=text value= <?php echo $array['area'];?>  name=area> </td>
							  </tr>
							  <tr> 
								  <td colspan =2><center><input type=submit value=Alterar></center> </td>
							  </tr>
					  	</form>
<!-----------FORMULÁRIO ---------------------------------------  -->
						 <form action="remove-medico.php" method="post">
								
								<table >	
									 <tr>
										 <td><input type=hidden value= <?php echo $array['id'];?> name=id>
										 <td>  <button> Remover  </button></td>
									 </tr>
								</table >
							 
						      </form> 
<!-------------------------------------------------  -->
                 	 </table >
              </center>
	 <?php }   
 }  
 
 //-----FUNÇÃO PARA ALTERAR(alterar) --------------------------------------------------
 
 function alterar($conexao,$id,$nome,$email,$senha,$cpf,$area){
	   
       	$sql = "UPDATE cadmed SET         nome='$nome',
       	                                    email = '$email', 
											senha= '$senha',
											cpf='$cpf',
											area = '$area'	WHERE id = $id";
		
		$resultado= mysqli_query($conexao,$sql);
	     
     return $resultado;
  }
  //-----------------------------------------------------------------------
 