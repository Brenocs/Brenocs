<?php require_once("conecta.php") ?>
  <?php require_once("banco-relatorio.php") ?>

<?php 

 $id = $_POST['id'];
 removeRelatorio($conexao,$id);
 
 header("Location:formListarrelatorio.php?removido=true");
 

?>