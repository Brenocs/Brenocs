<?php require_once ("conecta.php")?>
<?php require_once ("banco-paciente.php")?>
<?php require_once ("Paciente.php")?>

<?php
	$paciente = new paciente();
	$paciente->cpf=$_POST["cpf"];
	$paciente->nome=$_POST["nome"];
	$paciente->rg=$_POST["rg"];
	$paciente->email=$_POST["email"];
	$paciente->nascimento=$_POST["nascimento"];
	$paciente->logradouro=$_POST["logradouro"];
	$paciente->numero=$_POST["numero"];
	$paciente->bairro=$_POST["bairro"];
	$paciente->cidade=$_POST["cidade"];
	$paciente->estado=$_POST["estado"];
	$paciente->sexo=$_POST["sexo"];
	$paciente->doencas=$_POST["doencas"];
	$paciente->dtexame=$_POST["dtexame"];
	$paciente->horario=$_POST["horario"];
	$paciente->lexame=$_POST["lexame"];
	$paciente->texame=$_POST["texame"];
	$paciente->obs=$_POST["obs"];

	
	

if (inserepaciente($conexao, $paciente)){  ?>
			 <center>
			    
			   <table >
			   <tr><br>
			      <th>Cadastrado com sucesso!</th>
			   </tr>
			     <tr>
			       <td><br>CPF:  <?php echo $paciente->cpf; ?></td>
				</tr>
			    <tr>
			       <td>Nome:   <?php echo $paciente->nome; ?></td>
				</tr>
				<tr>
			       <td>RG: <?php  echo$paciente->rg; ?></td>
				</tr>
				<tr>
			       <td>Email: <?php  echo$paciente->email; ?></td>
				</tr>
				<tr>
			      <td>Nascimento: <?php  echo$paciente->nascimento; ?></td>
				</tr>
				<tr>
			       <td>Logradouro: <?php  echo$paciente->logradouro; ?></td>
				</tr>
				<tr>
			       <td>Número : <?php  echo$paciente->numero; ?></td>
				</tr>
				<tr>
			       <td>Bairro : <?php  echo$paciente->bairro; ?></td>
				</tr>
                <tr>
			       <td>Cidade : <?php  echo$paciente->cidade; ?></td>
				</tr>
                <tr>
			       <td>Estado: <?php  echo$paciente->estado; ?></td>
				</tr>
                <tr>
			       <td>Sexo : <?php  echo$paciente->sexo; ?></td>
				</tr>
                <tr>
			       <td>Doenças Prescritas : <?php  echo$paciente->doencas; ?></td>
				</tr>
                <tr>
			       <td>Data do Exame : <?php  echo$paciente->dtexame; ?></td>
				</tr>
                <tr>
			       <td>Horário de Exame : <?php  echo$paciente->horario; ?></td>
				</tr>
                <tr>
			       <td>Local do Exame : <?php  echo$paciente->lexame; ?></td>
				</tr>
                <tr>
			       <td>Tipo do Exame : <?php  echo$paciente->texame; ?></td>
				</tr>
                <tr>
			       <td>Obs : <?php  echo$paciente->obs; ?></td>
				</tr>



				</table>
		<?php
	
		      }else{
		?>
			  <h3>Paciente não adicionado!!</h3>
			
		<?php echo mysqli_error($conexao);
		
			  }
		
		?>
		<!--
<link rel="Stylesheet" href="css/bootstrap.css">
<br><br><br><br>
   <!-- <a href="formListar.php" button type="submit" class="btn btn-default btn-sm active" role="button">Listar</a></button></button><br><br>-->
 <!--<br/><a href="localizar.php">LOCALIZAR</a> <br><br>
 <a href="Apresentacao.php" button type="submit" class="btn btn-default btn-sm active" role="button">Voltar</a></button>-->

</center>