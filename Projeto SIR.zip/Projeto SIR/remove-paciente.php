<?php require_once("conecta.php") ?>
  <?php require_once("banco-paciente.php") ?>

<?php 

 $id = $_POST['id'];
 removePaciente($conexao,$id);
 
 header("Location:formListarpaciente.php?removido=true");
 

?>