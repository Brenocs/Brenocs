
 <?php require_once("Relatorio.php") ?>
 <?php require_once("conecta.php") ?>
 <?php require_once("banco-relatorio.php") ?>
<h1> <center>Listar Relatórios</center> </h1>
<?php	  
  listaRelatorio($conexao);
?>