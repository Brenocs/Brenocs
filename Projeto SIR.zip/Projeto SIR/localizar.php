<?php require_once("conecta.php") ?>

<html>
  <body>
  <center>
     <h1> Digite o nome do Paciente </h1>
		<form method="POST" action="localizar-recebe.php?a=buscar">
			<input type="text"   name="palavra" />
			<input type="submit" value="Buscar" />
		</form>
   <center>
 </body>
</html>

