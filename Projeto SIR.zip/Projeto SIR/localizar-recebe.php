	   <?php require_once("conecta.php") ?>
	   <?php require_once("Relatorio.php") ?>
       <?php require_once("banco-relatorio.php") ?>
<?php
    $a = $_GET['a']; 
?><center><h1> Resultado da Pesquisa </h1>
  <h5>
<?php
//inserir aqui o código para localizar
		if ($a=="buscar"){
		$palavra = trim($_POST['palavra']);
		$sql =("select * from relatorio
		       where nome like'%".$palavra."%' order by nome");
		$resultado=mysqli_query($conexao,$sql);
        $numRegistros=mysqli_num_rows($resultado);
           if ($numRegistros !=0) {
                 while($exibe= mysqli_fetch_object($resultado)){
                       echo   $exibe->cpf."-""<br/>"
                             .$exibe->nome."<br/>"
							  $exibe->prontuario."<br/>";
				 }
		   }else{		 
                      echo"Nenhum dado foi encontrado com a palavra"
                          .$palavra."";
		   }
		}
?>
 </h5></center>