<?php require_once("Familia.php") ?>
    <?php

// -------MÉTODO PARA INSERIR------------------------------
	  function insereFamilia($conexao,$familia){ 

		$sql="insert into cadfam(nome,email,senha,cpf) values 
			('$familia->nome',
			 '$familia->email',
			 '$familia->senha',
			 '$familia->cpf'
			)";
			$resultado =mysqli_query($conexao, $sql);
         return $resultado ;
	    }
		
// --------MÉTODO PARA DELETAR(alterar)--------------------------------------------------------------------

	
		function removeMedico($conexao,$id) {
				$sql ="delete from cadfam where id = '$id';";
				$resultado =mysqli_query ($conexao,$sql);   
	    return $resultado; 
		}
	
		 

//---------MÉTODO PARA LISTAR------------------------------------------------------------------------------
	
		 function listaMedico($conexao){
			  
				$sql="select  * from cadfam";
				$resultado= mysqli_query($conexao,$sql );
				 
		 while($array=mysqli_fetch_assoc($resultado)) { ?>
					
			  <center>
					 <form action=alterarFormfamilia.php  method=GET>
	                  <table >
							  <tr>
								  
								   <td><input type=hidden value= <?php echo $array['id'];?> name=id> </td> 
							  </tr>
							  <tr>
								   <td>Nome</td>
								   <td> <input type=text value= <?php echo $array['nome'];?>  name=nome> </td>
							  </tr>
							   <tr>
								   <td>Email</td>
								   <td> <input type=text value= <?php echo $array['email'];?>  name=email> </td>
							  </tr>
							  <tr>
								   <td>Senha</td>
								   <td> <input type=text value= <?php echo $array['senha'];?>  name=senha> </td>
							  </tr>
							  <tr>
								   <td>CPF</td>
								   <td> <input type=text value= <?php echo $array['cpf'];?>  name=cpf> </td>
							  </tr>
							  <tr> 
								  <td colspan =2><center><input type=submit value=Alterar></center> </td>
							  </tr>
					  	</form>
<!-----------FORMULÁRIO ---------------------------------------  -->
						 <form action="remove-familia.php" method="post">
								
								<table >	
									 <tr>
										 <td><input type=hidden value= <?php echo $array['id'];?> name=id>
										 <td>  <button> Remover  </button></td>
									 </tr>
								</table >
							 
						      </form> 
<!-------------------------------------------------  -->
                 	 </table >
              </center>
	 <?php }   
 }  
 
 //-----FUNÇÃO PARA ALTERAR(alterar) --------------------------------------------------
 
 function alterar($conexao,$id,$nome,$email,$senha,$cpf){
	   
       	$sql = "UPDATE cadfam SET         nome='$nome',
       	                                    email = '$email', 
											senha= '$senha',
											cpf='$cpf'  WHERE id = $id";
		
		$resultado= mysqli_query($conexao,$sql);
	     
     return $resultado;
  }
  //-----------------------------------------------------------------------
 