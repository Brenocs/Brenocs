<?php
 $conexao = mysqli_connect('localhost','root','','projeto2'); 

 ?>