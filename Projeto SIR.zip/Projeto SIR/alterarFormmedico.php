 <?php require_once("Medico.php") ?>
 <?php require_once("conecta.php") ?>
 <?php require_once("banco-medico.php") ?>
 
 <?php
               $id=  $_GET["id"];
			   $nome=$_GET["nome"];
			   $cpf= $_GET["email"];
	           $senha=$_GET["senha"];
	           $cpf= $_GET["cpf"];
			   $area=$_GET["area"];
			   
 alterar($conexao,$id,$nome,$email,$enha,$cpf,$area);
    header("Location:formListarmedico.php?removido=true");
 
  ?>
  